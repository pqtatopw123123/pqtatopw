
<?php 
/*
 *	Made by Samerton
 *  http://worldscapemc.co.uk
 *
 *  Translated by Aviortheking
 *  https://delta-wings.net/
 *
 *  License: MIT
 * Copyright (c) 2017 Samerton
 */
// Language file for "Donate" addon
$donate_language = array(
	'donate' => 'Donation',
	'donate_icon' => '', // Icon to display before "Donate" in navbar
	'latest_donors' => 'Dernier donateurs',
	'agree_with_terms' => 'En faisant une donation vous accepter les termes et conditions',
	'link' => '(Lien)',
	'agree' => 'Accepter &raquo;',
	'cancel' => 'Annuler',
	'select' => 'Séléctionner'
);
