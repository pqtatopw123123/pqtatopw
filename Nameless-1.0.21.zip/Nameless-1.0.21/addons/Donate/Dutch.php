<?php 
/*
 *	Made by Samerton
 *  http://worldscapemc.co.uk
 *
 *  License: MIT
 *  Copyright (c) 2016 Samerton
 */
// Translation made by jesseke55 on GitHub
// Language file for "Donate" addon

$donate_language = array(
	'donate' => 'Doneer',
	'donate_icon' => '',
	'latest_donors' => 'Recente donateurs',
	'agree_with_terms' => 'Door te doneren ga je akkoord met de regels daarvan.',
	'link' => '(Link)',
	'agree' => 'Akkoord &raquo;',
	'cancel' => 'Annuleren',
	'select' => 'Selecteren'
);
